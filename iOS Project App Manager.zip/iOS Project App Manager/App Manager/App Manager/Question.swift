//
//  Question.swift
//  Quizzler
//
//  Created by MacOS Mojave 10.14.3 on 7/18/19.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import Foundation

class Question{
    
    //properties of Queston Class
    
    let questionText : String
    let answer : Bool
    
    //determines what happens when a neq question object is created from this Question class
    init(text: String, correctAnswer: Bool){
        
        questionText=text
        answer=correctAnswer
    }
    
    
}
