//
//  WelcomeViewController.swift
//  
//
//  This is the welcome view controller - the first thign the user sees
//

import UIKit
import Firebase


class WelcomeViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //If there is a logged in user, by pass this screen and go straight to ChatViewController
        
        /*if Auth.auth().currentUser != nil {
            performSegue(withIdentifier: "goToChat", sender: self)
        }*/
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func loginPressed(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "goToLogin", sender: self)
    }
    
    @IBAction func registerPressed(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "goToRegister", sender: self)
    }
}
