

import Foundation
import UIKit

class MainViewController: UIViewController
{
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // do any additional setup after loading the view, typically from a nib
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // dispose of any resources that can be recreated
    }
    
    
    @IBAction func goToChat(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "goToChat", sender: self)
    }
    
    
    @IBAction func goToQuiz(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "goToQuiz", sender: self)
    }
    
    @IBAction func goToDice(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "goToDice", sender: self)
    }
    
}


