

import Foundation
import UIKit
import SVProgressHUD

class QuizViewController: UIViewController
{
    
    
    let allQuestions = QuestionBank()
    var pickedAnswer : Bool = false
    //this var is going to keep track of the state of which question is the user on
    var questionNum : Int = 0
    var score : Int = 0
    
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var progressBar: UIView!
    @IBOutlet weak var progressLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        nextQuestion()
        
    }
    
    
    @IBAction func answerPressed(_ sender: UIButton)
    {
        if sender.tag == 1 {
            
            pickedAnswer = true
            
        }
        else if sender.tag == 2 {
            pickedAnswer = false
        }
        
        checkAnswer()
        
        questionNum = questionNum + 1
        nextQuestion()
    }
    
    func updateUI() {
        
        scoreLabel.text = "Score: \(score)"
        progressLabel.text = "\(questionNum + 1) / 13"
        
        progressBar.frame.size.width = (view.frame.size.width / 13) * CGFloat(questionNum)
    }
    
    
    func nextQuestion() {
        
        if questionNum <= 12{
            questionLabel.text = allQuestions.list[questionNum].questionText
            updateUI()
        }
        else{
            
            let alert = UIAlertController(title: "Awesome", message: "You've finished all the questions, do you want to start over?", preferredStyle: .alert)
            
            let restartAction = UIAlertAction(title: "Restart", style: .default, handler: { (UIAlertAction) in self.startOver()
                
            })
            alert.addAction(restartAction)
            
            present(alert, animated: true, completion: nil)
        }
    }
    
    
    func checkAnswer() {
        
        let correctAnswer = allQuestions.list[questionNum].answer
        
        if correctAnswer == pickedAnswer {
            
            //ProgressHUD.showSuccess("Correct")
            SVProgressHUD.showSuccess(withStatus: "Correct")
            score = score + 1
        }
        else
        {
            //ProgressHUD.showError("Error")
            SVProgressHUD.showError(withStatus: "Error")
        }

        
    }
    
    
    func startOver() {
        
        questionNum = 0
        nextQuestion()
    }
    
}
